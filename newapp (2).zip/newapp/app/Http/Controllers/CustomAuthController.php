<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Response;
use App\Models\User;
use App\Models\Note;
use Hash;
use Session;
use DB;

class CustomAuthController extends Controller
{
    public function login(){
    return view('login');
    }
    public function registration(){
    return view('registration');    
    }
    public function registerUser(Request $request){
    $request->validate([
    'name'=>'required|regex:/^[A-Z]+$/i',
    'email'=>'required|email|unique:users',
    'password'=>'required|min:5|max:12',   
    ]);
    $user = new User();
    $user->name = $request->name;
    $user->email = $request->email;
    $user->password = Hash::make($request->password);
    $request = $user->save();
    if($request){
    return back()->with('success','you have registered successfully');
    }else{
    return back()->with('fail','something wrong');
    }
    }
    public function loginUser(Request $request){
    $request->validate([       
    'email'=>'required|email',
    'password'=>'required|min:5|max:12'           
    ]);
    $user = User::where('email', '=' , $request->email)->first();
    if($user) {
    if (Hash::check($request->password, $user->password)) {
    $request->session()->put('loginId',$user->id);
    return redirect('dashboard');                
    } else {
    return back()->with('fail','Password not matches.');
    }
    } else {            
    return back()->with('fail','This email is not registered.');
    }
    }
    public function dashboard(){
    $data = array();
    if (Session::has('loginId')) {
    $data = User::where('id', '=' , Session::get('loginId'))->first();           
    }
    return view('dashboard',compact('data'));      
    }
    public function logout(){
    if (Session::has('loginId')) {
    Session::pull('loginId');
    return redirect('login');
    }
    }
    public function index(){
    return view('home');
    }
    public function create(){
    $user = User::find(1);
    $note = new Note;
    $note->phone_number = "8888";
    $note->address = "asdffgh";
    $user->note()->save($note);
    return 'Saved';
    }
    public function update(){
    $user = User::find(1);
    $note = new Note;
    $note->phone_number = "1234";
    $note->address = "asdffgh";
    $user->note()->update($note->toArray());
    return 'updated';
    }
    public function view(){
    $user = User::with('note')->whereId(1)->first();
    return Response::json($user);
    }
    public function destroy()
    {
    $user = User::find(1);
    $note = new Note;
    $user->note()->delete($note->toArray());
    return 'deleted';
    }
    
 
   
}

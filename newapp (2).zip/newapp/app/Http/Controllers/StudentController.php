<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Response;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Comment;

class StudentController extends Controller
{
    public function index(){
    $comment = Comment::with('post')->whereId(1)->first();
    return Response::json($comment);
    }
    public function create(){
    $post = Post::find(1);
    $comment = new Comment;
    $comment->name = "opq";
    $post->comments()->save($comment);
    return 'saved';
    }
    public function store(){
    $post = Post::find(2);
    $comment = Comment::find(1);
    $comment = new Comment;
    $comment->name = "mnop";
    $post->comments()->update($comment->toArray());
    return 'stored';
    }
    public function update(){
    $comment = Comment::find(1);
    $post = Post::find(2);
    $comment->post()->associate($post)->save();
    return 'updated';
    }
    public function delete()
    {
    $post = Post::find(1);
    $comment = new Comment;
    $post->comments()->delete($comment->toArray());
    return 'deleted';
    }
    
   
} 



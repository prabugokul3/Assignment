<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomAuthController;
use App\Http\Controllers\StudentController;
use App\Models\Note;
use App\Models\User;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/login',[CustomAuthController::class,'login'])->middleware('alreadyLoggedIn');
Route::get('/registration',[CustomAuthController::class,'registration'])->middleware('alreadyLoggedIn');
Route::post('/register-user',[CustomAuthController::class,'registerUser'])->name('register-user');
Route::post('/login-user',[CustomAuthController::class,'loginUser'])->name('login-user');
Route::get('/dashboard',[CustomAuthController::class,'dashboard'])->middleware('isLoggedIn');
Route::get('/logout',[CustomAuthController::class,'logout']);
Route::get('/home',[CustomAuthController::class,'home']);
Route::get('/',[CustomAuthController::class,'create']);
Route::get('/updated',[CustomAuthController::class,'update']);
Route::get('/view',[CustomAuthController::class,'view']);
Route::get('/index',[StudentController::class,'index']);
Route::get('/create',[StudentController::class,'create']);
Route::get('/update',[StudentController::class,'update']);
Route::get('/store',[StudentController::class,'store']);
Route::get('/delete',[CustomAuthController::class,'destroy']);
Route::get('/destroy',[StudentController::class,'delete']);


